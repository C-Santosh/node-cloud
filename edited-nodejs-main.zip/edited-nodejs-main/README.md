IT CAN BE FREQUENTLY EDITED.


Here I am trying to create a node.js website the docker file and push the image to ECR and also use ECS Services.
https://www.digitalocean.com/community/tutorials/how-to-build-a-node-js-application-with-docker
use the above link to help you out, for any more doubts you have 
https://docs.docker.com/language/nodejs/build-images/
one more to help out, its from official docker account blog.

Official Docker link for Multiple Code Dockerfile Building:
https://docs.docker.com/language/

